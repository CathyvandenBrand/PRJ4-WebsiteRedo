function myFunction() {
    alert("");
  }

  function myFunction1() {
    alert("Neighbourhood pack"+"\nA advanced pack to help you and your neighbourhood to become cleaner and a better place to live with flyers to inform neighbours, Bio degradable sticker pack, 5 rolls of plastic bags, 10 rolls of green bags. 20 packs of flower seeds, a trash calendar and a nice bag for nice trips trough your cleaner and greener neighbourhood.");
  }
  function myFunction2() {
    alert("Class pack \nDo you want to teach your students about their carbon food print and give them a start into a cleaner and greener future than please reach out to us on our email blossom@hotmail.com for potential guest lectures with of course fun goody bags. ");
  }